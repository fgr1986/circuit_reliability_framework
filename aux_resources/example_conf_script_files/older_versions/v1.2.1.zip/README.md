VERSION=v1.1.3

****************************
#SCS Netlists:
* Standard Spectre Sintax
* Absolut paths (needs to be considered)

****************************
#XML conf files

##Experiment XML conf file
```
<?xml version="1.0"?>
<!-- Non default values (value_min, value_max, value step, etc) 
	should be in an exponential based format, ex: '0.2e3' -->
<!-- Magnitude time is needed!!! -->
<root>
	<radiation_simulator_target_version>v1.1.3</radiation_simulator_target_version>
	<experiment_title>Inverter test</experiment_title>
	<save_all_simulations>true</save_all_simulations>
	<processed_magnitudes>
		<magnitude>
			<magnitude_name>time</magnitude_name>
			<magnitude_analyzable>false</magnitude_analyzable>
			<magnitude_abs_error_margin>0</magnitude_abs_error_margin>
			<magnitude_analyze_error_in_time>false</magnitude_analyze_error_in_time>
			<magnitude_error_time_span>0</magnitude_error_time_span>
		</magnitude>
		<magnitude>
			<magnitude_name>mag_name</magnitude_name>
			<magnitude_analyzable>true/false</magnitude_analyzable>
			<magnitude_abs_error_margin>magnitude_abs_error_margin(double)</magnitude_abs_error_margin>
			<magnitude_analyze_error_in_time>true/false</magnitude_analyze_error_in_time>
			<magnitude_error_time_span>time_span(double)</magnitude_error_time_span>
		</magnitude>
		...
	</processed_magnitudes>
	<injection_radiation_sources_info>
		<radiation_sources_netlist>injection_netlist_path</radiation_sources_netlist>
		<radiation_sources>
			<radiation_source>
				<radiation_source_name>source_name</radiation_source_name>
				<radiation_source_subcircuit_name>subcircuit_name</radiation_source_subcircuit_name>
				<radiation_source_substitute_statement>false</radiation_source_substitute_statement>
				<radiation_source_node>Node_name</radiation_source_node>
				<radiation_parameters>
					<radiation_parameter>
						<radiation_parameter_name>param_name</radiation_parameter_name>
						<radiation_parameter_default_value>def_value(string)</radiation_parameter_default_value>
						<radiation_parameter_value_min>min_value(double)</radiation_parameter_value_min>
						<radiation_parameter_value_max>max_value(double)</radiation_parameter_value_max>
						<radiation_parameter_value_stop_percentage>percent(double)</radiation_parameter_value_stop_percentage>
						<radiation_parameter_fixed>false/true</radiation_parameter_fixed>
						<radiation_parameter_allow_find_critical_value>true/false</radiation_parameter_allow_find_critical_value>
						<radiation_parameter_value_lineal_change>false/true</radiation_parameter_value_lineal_change>
					</radiation_parameter>
					....
				</radiation_parameters>	
			</radiation_source>
		</radiation_sources>
		<injectable_statements>
			<statement>
				<master_name>statement_master_name</master_name>
			</statement>
			...
		</injectable_statements>	
	</injection_radiation_sources_info>
	<replacement_radiation_sources_info>
		<radiation_sources_netlist>../conf_files/substitute_radiation_sources.scs</radiation_sources_netlist>
		<radiation_sources>
			<radiation_source>
				<radiation_source_name>source_name</radiation_source_name>
				<radiation_source_subcircuit_name>source_subcircuit_name</radiation_source_subcircuit_name>
				<radiation_source_substitute_statement>true</radiation_source_substitute_statement>
				<radiation_source_node>nothing</radiation_source_node>
				<radiation_parameters>					
					<radiation_parameter>
						<radiation_parameter_name>param_name</radiation_parameter_name>
						<radiation_parameter_default_value>def_value(string)</radiation_parameter_default_value>
						<radiation_parameter_value_min>min_value(double)</radiation_parameter_value_min>
						<radiation_parameter_value_max>max_value(double)</radiation_parameter_value_max>
						<radiation_parameter_value_stop_percentage>percent(double)</radiation_parameter_value_stop_percentage>
						<radiation_parameter_fixed>false/true</radiation_parameter_fixed>
						<radiation_parameter_allow_find_critical_value>true/false</radiation_parameter_allow_find_critical_value>
						<radiation_parameter_value_lineal_change>false/true</radiation_parameter_value_lineal_change>
					</radiation_parameter>
					...
				</radiation_parameters>
			</radiation_source>
			...
		</radiation_sources>
		<replaceable_statements>
			<statement>
				<master_name>statement_name</master_name>
				<substitute_master_name>altered_statement_name</substitute_master_name>
			</statement>
			...
		</replaceable_statements>
	</replacement_radiation_sources_info>
	<!-- Nodes that not depend on the technology (but on the circuit design) and are not going to be radiated in the Injection Scheme-->
	<exp_unalterable_nodes>
		<exp_unalterable_node>
			<exp_unalterable_node_name>unalterable_node_name</exp_unalterable_node_name>
		</exp_unalterable_node>
	</exp_unalterable_nodes>
	<!-- Statements that are not going to be radiated/substituted, as well as its children-->
	<unalterable_statements>
		<statement>
			<master_name>statement_master_name</master_name>
		</statement>
	</unalterable_statements>
</root>

```

##Technology XML conf file
```
<?xml version="1.0"?>
<root>
	<technology>tech</technology>
	<radiation_simulator_target_version>v0.8.8</radiation_simulator_target_version>
	<excluded_folders>
		<excluded_folder>
			<excluded_folder_name>tsmc40nm models</excluded_folder_name>
			<excluded_folder_path>/opt/cadence/tsmc40nm</excluded_folder_path>
		</excluded_folder>
	</excluded_folders>
	<transistors>
		<statement name="name">
			<master_name>name</master_name>
			<description>desc</description>
			<nodes>
				<node>
					<position>0</position>
					<name>name</name>
				</node>
			...
			</nodes>
		</statement>
		...
	</transistors>
	<tech_unalterable_nodes>
		<tech_unalterable_node>
			<tech_unalterable_node_name>node name</tech_unalterable_node_name>
		</tech_unalterable_node>
		...
	</tech_unalterable_nodes>
</root>
```

##Cadence XML conf file
```
<?xml version="1.0"?>
<root>	
	<radiation_simulator_target_version>v0.8.8</radiation_simulator_target_version>
	<cadence_version>Spectre 12.1.1.164.isr15 64bit -- 26 Oct 2013</cadence_version>
	<spectre_run_command>
		<spectre_example_command>screen -dmS spectreSim$j spectre +log $log_file -f psfascii -r $sim_folder $netlist +error +warn > $standard_log.log</spectre_example_command>
		<pre_spectre_command>screen -dmS</pre_spectre_command>
		<spectre_command>spectre -f psfascii +error +warn</spectre_command>
		<spectre_command_log_arg>+log</spectre_command_log_arg>
		<spectre_command_folder_arg>-r</spectre_command_dir_arg>
		<post_spectre_command>></post_spectre_command>
	</spectre_run_command>
	<bsource_statements>
		<statement name="name">
			<bsource_type>type (int) </bsource_type>
			<master_name>master_name</master_name>
			<description>desc</description>
		</statement>
		...
	</bsource_statements>
	<primitives>
		<primitive>
			<primitive_name>a2d</primitive_name>
		</primitive>
		...
	</primitives>
	<analyses>
		<statement name="name">
			<master_name>name</master_name>
			<advanced_analysis>false/true</advanced_analysis>
			<description>desc</description>
		</statement>
		...
	</analyses>
	<control_statements>
		<statement name="name">
			<master_name>master name</master_name>
			<advanced_control_statement>false/true</advanced_control_statement>
			<special_syntax_control_statement>false/true</special_syntax_control_statement>
			<description>desc</description>
		</statement>
		...
	</control_statements>
	<keywords>
		<keyword>
			<keyword_name>name</keyword_name>
			<type>type</type>
		</keyword>
		...
	</keywords>
</root>
```
