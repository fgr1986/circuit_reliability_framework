#!/bin/sh

for params in l w ad as pd ps L W AD AS PD PS ; do

sed -i "s/${params}=/${params}_SI=/g" $1

echo "changed ${params} to ${params}_SI"

done


