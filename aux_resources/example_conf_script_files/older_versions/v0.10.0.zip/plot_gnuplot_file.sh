set key outside
plot for [col=1:6] 'file' using 0:col with lines
