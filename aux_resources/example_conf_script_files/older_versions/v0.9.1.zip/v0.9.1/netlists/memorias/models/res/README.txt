README.txt -- res


(1) Technology

	I3T80U


(2) Target Simulator

	Spectre 5.0.0
		This kit requires the "scale" option to be set to "1.0".
	        Device instances take geometrical parameters in microns.


(3) Kit organization

	Top-level files included by the CAD system are:			
		bip-Defaults.scs, bip-Matching.scs, bip-SOA.scs
		cap-Default.scs, cap-Matching.scs, cap_SOA.scs
		corners.cfg
		dio-Default.scs, dio-Matching.scs, dio-SOA.scs
		functions.scs
		HISTORY.txt
		matchingBipModule.scs, matchingMosModule.scs, matchingResModule.scs
		mos-Default.scs, mos-Matching.scs, mos-SOA.scs
		NOTE.txt
		README.txt
		res-Default.scs, res=Matching.scs, res-SOA.scs


(4)  Documentation

	The following documents are available:
		Model-kit release report (overview of kit contents)
		CMOS modeling report
		Capacitor modeling report
		Diode modeling report
		NPN and PNP modeling reports
		Resistor modeling report


(5) Features and Limitations

	Noise data was obtained from Fab10 silicon and is implemented for the following devices:
		hiporxwnl, nporxwnl, nprpwnl, nwarsbnl, nwrsbnl, pporxwnl, pprnwnl, pwarnenl, pwrnenl,
		hiporxwbb, nporxwbb, nprpwbb, nwarsbbb, nwrsbbb, pporxwbb, pprnwbb, pwarnebb, pwrnebb
	Noise is not implemented for the following devices:
		hipor, lopor, m1r, m2r, m3r, m4r, m5r, npor, nprpw, nwarsb, nwrsb, ppor, pprnw, pwarne, pwrne,
		loporxwnl,
		loporxwbb
		
	Monte Carlo matching data was obtained from Fab2 silicon and is implemented for the following devices:
		hiporxwnl, nporxwnl, pporxwnl, loporxwnl, nwarsbnl, nwrsbnl, pwarnenl, pwrnenl
		hiporxwbb, nporxwbb, pporxwbb, loporxwbb, nwarsbbb, nwrsbbb, pwarnebb, pwrnebb
		hipor, npor, ppor, lopor, nwarsb, nwrsb, pwarne, pwrne
	
	Monte Carlo matching is not implemented for the following devices:
		m1r, m2r, m3r, m4r, m5r, nprpw, pprnw,   
		nprpwnl, pprnwnl,
		nprpwbb, pprnwbb
	

	Amis-Match data was obtained from Fab2 silicon and is implemented for the following devices:
		hiporxwnl, nporxwnl, pporxwnl, loporxwnl, nwarsbnl, nwrsbnl, pwarnenl, pwrnenl
		hiporxwbb, nporxwbb, pporxwbb, loporxwbb, nwarsbbb, nwrsbbb, pwarnebb, pwrnebb
		hipor, npor, ppor, lopor, nwarsb, nwrsb, pwarne, pwrne
	 
	Amis-Match is not implemented for the following devices:
		m1r, m2r, m3r, m4r, m5r, nprpw, pprnw,  
		nprpwnl, pprnwnl, 
		nprpwbb, pprnwbb
(6) Contact

	Please send any questions to the following email address:
	Mixed Signal CAD Support <mscad-support@amis.com>