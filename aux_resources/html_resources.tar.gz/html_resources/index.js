var $statement_properties;
var $simulation_properties;
var $dialogModal;

$(document).ready(function() {
	init();
});

function init(){

	$up = $('#up');
	$up.click( function(){
		scrollTop();
	});
	
	$statement_properties = $('.statement_properties');
	$statement_properties.hide( 'slow');
	$('.show_statement_properties').click(function() {
		$statement_properties.hide();
		var aux_id= "#statement_properties_" + $(this).attr('id').split("_")[3];
		$(aux_id).show();
	});
	
	$simulation_properties = $('.simulation_properties');
	$simulation_properties.hide();	
	$('.show_simulation_properties').click(function() {
		$simulation_properties.hide( 'slow');
		var aux_id= "#simulation_properties_" + $(this).attr('id').split("_")[3];
		$(aux_id).show();
	});

	$dialogModal = $('#dialog_modal');
		
	$('.show_scenario_variation').click(function() {
		var splitted = $(this).attr('id').split("ssv_");
		// alert( splitted[1] );
		$dialogModal.load("simulations/" +  splitted[1] + ".html" , function() {
			$dialogModal.dialog({
				height: 800,
				width: 1100,
				modal: true,
				position:{
					my: "center",
					at: "center",
					of: window
				}
			});
		});
	});
}

function scrollTop(){	
	$('html, body').animate({
		scrollTop: $("#header").offset().top
	}, 1000); 
}

